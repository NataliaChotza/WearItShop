package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "managers", schema = "masdb", catalog = "")
public class ManagersEntity {
    private int id;
    private Integer yearsInCompany;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "years_in_company", nullable = true)
    public Integer getYearsInCompany() {
        return yearsInCompany;
    }

    public void setYearsInCompany(Integer yearsInCompany) {
        this.yearsInCompany = yearsInCompany;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ManagersEntity that = (ManagersEntity) o;
        return id == that.id &&
                Objects.equals(yearsInCompany, that.yearsInCompany);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, yearsInCompany);
    }
}
