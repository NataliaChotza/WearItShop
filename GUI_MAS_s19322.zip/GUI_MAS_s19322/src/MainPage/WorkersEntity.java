package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "workers", schema = "masdb", catalog = "")
public class WorkersEntity {
    private int id;
    private String pesel;
    private Double salary;
    private Integer shoplocaleId;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "PESEL", nullable = true, length = -1)
    public String getPesel() {
        return pesel;
    }

    public void setPesel(String pesel) {
        this.pesel = pesel;
    }

    @Basic
    @Column(name = "salary", nullable = true, precision = 0)
    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    @Basic
    @Column(name = "shoplocaleId", nullable = true)
    public Integer getShoplocaleId() {
        return shoplocaleId;
    }

    public void setShoplocaleId(Integer shoplocaleId) {
        this.shoplocaleId = shoplocaleId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WorkersEntity that = (WorkersEntity) o;
        return id == that.id &&
                Objects.equals(pesel, that.pesel) &&
                Objects.equals(salary, that.salary) &&
                Objects.equals(shoplocaleId, that.shoplocaleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, pesel, salary, shoplocaleId);
    }
}
