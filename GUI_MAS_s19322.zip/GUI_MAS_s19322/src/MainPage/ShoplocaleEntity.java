package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "shoplocale", schema = "masdb", catalog = "")
public class ShoplocaleEntity {
    private int shopId;
    private String streetName;
    private String streetNumber;

    @Id
    @Column(name = "shopId", nullable = false)
    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    @Basic
    @Column(name = "streetName", nullable = true, length = -1)
    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    @Basic
    @Column(name = "streetNumber", nullable = true, length = -1)
    public String getStreetNumber() {
        return streetNumber;
    }

    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ShoplocaleEntity that = (ShoplocaleEntity) o;
        return shopId == that.shopId &&
                Objects.equals(streetName, that.streetName) &&
                Objects.equals(streetNumber, that.streetNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(shopId, streetName, streetNumber);
    }
}
