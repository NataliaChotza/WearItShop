package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "l", schema = "masdb", catalog = "")
public class LEntity {
    private int idL;
    private Integer prodNumber;
    private Integer ammount;

    @Id
    @Column(name = "idL", nullable = false)
    public int getIdL() {
        return idL;
    }

    public void setIdL(int idL) {
        this.idL = idL;
    }

    @Basic
    @Column(name = "prodNumber", nullable = true)
    public Integer getProdNumber() {
        return prodNumber;
    }

    public void setProdNumber(Integer prodNumber) {
        this.prodNumber = prodNumber;
    }

    @Basic
    @Column(name = "ammount", nullable = true)
    public Integer getAmmount() {
        return ammount;
    }

    public void setAmmount(Integer ammount) {
        this.ammount = ammount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LEntity lEntity = (LEntity) o;
        return idL == lEntity.idL &&
                Objects.equals(prodNumber, lEntity.prodNumber) &&
                Objects.equals(ammount, lEntity.ammount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idL, prodNumber, ammount);
    }
}
