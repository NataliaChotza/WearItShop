package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "messages", schema = "masdb")//, catalog = "")
public class MessagesEntity {
    private int idMsg;
    private Integer idClient;
    private Integer idWorker;
    private String msg;
    private String title;

    @Id
    @Column(name = "idMsg", nullable = false)
    public int getIdMsg() {
        return idMsg;
    }

    public void setIdMsg(int idMsg) {
        this.idMsg = idMsg;
    }

    @Basic
    @Column(name = "idClient", nullable = true)
    public Integer getIdClient() {
        return idClient;
    }

    public void setIdClient(Integer idClient) {
        this.idClient = idClient;
    }

    @Basic
    @Column(name = "idWorker", nullable = true)
    public Integer getIdWorker() {
        return idWorker;
    }

    public void setIdWorker(Integer idWorker) {
        this.idWorker = idWorker;
    }

    @Basic
    @Column(name = "msg", nullable = true, length = -1)
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Basic
    @Column(name = "title", nullable = true, length = -1)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MessagesEntity that = (MessagesEntity) o;
        return idMsg == that.idMsg &&
                Objects.equals(idClient, that.idClient) &&
                Objects.equals(idWorker, that.idWorker) &&
                Objects.equals(msg, that.msg) &&
                Objects.equals(title, that.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idMsg, idClient, idWorker, msg, title);
    }
}
