package MainPage;

import java.sql.*;

public class DBConnection {


    public static Connection conDB() {
        {
            try {
                //Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/masdb","natalia","Natalia1665");
                return con;
            } catch (SQLException e) {
                return null;
            }

        }

    }
}