package MainPage;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "prodlist", schema = "masdb")//, catalog = "")
public class ProdlistEntity {
    private Integer orderNumber;
    private Integer prodNumber;

    @Basic
    @Column(name = "orderNumber", nullable = true)
    public Integer getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }

    @Basic
    @Column(name = "prodNumber", nullable = true)
    public Integer getProdNumber() {
        return prodNumber;
    }

    public void setProdNumber(Integer prodNumber) {
        this.prodNumber = prodNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProdlistEntity that = (ProdlistEntity) o;
        return Objects.equals(orderNumber, that.orderNumber) &&
                Objects.equals(prodNumber, that.prodNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderNumber, prodNumber);
    }
}
