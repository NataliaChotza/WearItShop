package MainPage;


import com.sun.jndi.cosnaming.CNCtx;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import javax.persistence.criteria.CriteriaBuilder;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    public Button login;
    public Button SIgnIn;
    public Label lblForgot;
    public TextField lblUserName;
    public PasswordField lblPassword;
    public Label lblIncorrect;
    public Button signUpButton;
    public TextField txtNewUser;
    public PasswordField txtNewPass;
    public PasswordField txtNewPass2;
    public MenuButton Categories;
    public MenuItem WomanCat;
    public MenuItem ManCat;
    public MenuItem ChildCat;
    public Label lblColors1;
    public Label lblSizes1;
    public Label lblPrice1;
    public Label lblColors2;
    public Label lblSizes2;
    public Label lblPrice2;
    public TextField txtProdCode1;
    @FXML
    TextField txtProdCode2;
    @FXML
    Button showDetails1;
    @FXML
    Label lblProdName1;
    @FXML
    Label lblProdName2;
    @FXML
    Button showDetails2;


    @FXML
    Button update;
    @FXML
    Label lblProdName3;
    @FXML
    Button showDetails3;
    @FXML
    Label lblColors3;
    @FXML
    Label lblSizes3;
    @FXML
    Label lblPrice3;
    @FXML
    TextField txtProdCode3;


    @FXML
    Button cart;
    @FXML
    CheckBox addBox1;
    @FXML
    CheckBox addBox2;
    @FXML
    CheckBox addBox3;
    @FXML
    Label lblError;

    public Label lblorder1;
    public Label lblorder2;
    public Label lblorder3;
    public TextField toPay;
    @FXML
    Button checkOutButton;
    @FXML
    Button backOrder;
    @FXML
    MenuButton Colour1;
    @FXML
    MenuButton Colour2;
    @FXML
    MenuButton Colour3;

    public MenuItem c1;
    public MenuItem c11;
    public MenuItem c2;
    public MenuItem c22;
    public MenuItem c3;
    public MenuItem c33;

    public MenuItem s1,s11,s111,s1111;
    public MenuItem s2,s22,s222,s2222;
    public MenuItem s3,s33,s333,s3333;
    @FXML
    MenuButton Size1;
    @FXML
    MenuButton Size2;
    @FXML
    MenuButton Size3;

    @FXML
    Button nextButton;


    Connection con;
    PreparedStatement prep = null;
    ResultSet resultSet = null;
    Node node = null;
    ParameterMetaData param = null;
    public static String prodNumber1 = "100";
    public static String prodNumber2 = "103";
    public static String prodNumber3 = "102";
    public static String user;
    public static boolean Box1Distable ;
    public static boolean Box2Distable ;
    public static boolean Box3Distable ;

    public Controller() {
        con = DBConnection.conDB();
    }

    public void setUserIsLogged(String user) {
        Controller.user =user;
    }

    public String getUserIsLogged() {
        return Controller.user;
    }
    public String getProdNumber1(){
        return Controller.prodNumber1;
    }
    public String getProdNumber2(){
        return Controller.prodNumber2;
    }
    public String getProdNumber3(){
        return Controller.prodNumber3;
    }



/**@param event
 * This a main method used by every component in GUI javafx.
 * @throws IOException
 *
 * */
    public void handleButtonAction(ActionEvent event) throws IOException {
        System.out.println(event.getSource());

        if (event.getSource() == SIgnIn) {
            loginButton(event);
        }
        if (event.getSource() == login) {
            try {
                window("login.fxml", event, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (event.getSource() == signUpButton) {
            signUp();
        }
        if (event.getSource() == WomanCat) {
            if (getUserIsLogged() == null) {
                Categories.getScene();
                window("womanCat.fxml", event, Categories.getScene());
            } else
                window("womanCatAfterLogin.fxml", event, Categories.getScene());
        }
        if (event.getSource() == showDetails1) {
            LabelsWCat("100", lblPrice1, lblColors1, lblProdName1, txtProdCode1, lblSizes1);
        }
        if (event.getSource() == showDetails2) {
            LabelsWCat("103", lblPrice2, lblColors2, lblProdName2, txtProdCode2, lblSizes2);
        }
        if (event.getSource() == showDetails3) {
            LabelsWCat("102", lblPrice3, lblColors3, lblProdName3, txtProdCode3, lblSizes3);
        }
        if (event.getSource() == addBox1) {
            add(event, addBox1.getScene(), getProdNumber1());
            addBox1.setDisable(true);
            Controller.Box1Distable=true;
        }
        if (event.getSource() == addBox2) {
            add(event, addBox2.getScene(), getProdNumber2());
            addBox2.setDisable(true);
            Controller.Box2Distable=true;
        }
        if (event.getSource() == addBox3) {
            add(event, addBox3.getScene(), getProdNumber3());
            addBox3.setDisable(true);
            Controller.Box3Distable=true;
        }
        if ((event.getSource() == cart) || (event.getSource() == backOrder)) {
            window("Order.fxml", event, null);

        }
        if (event.getSource() == checkOutButton) {
            window("pay.fxml", event,null);
        }
        if(event.getSource()==ManCat){
            if (getUserIsLogged() == null) {
                window("Man.fxml", event, Categories.getScene());
            }else{
                window("ManAfterLogin.fxml",event,Categories.getScene());
            }
        }
        if(event.getSource()==ChildCat){
            if (getUserIsLogged() == null) {
                window("Child.fxml", event, Categories.getScene());
            }else{
                window("ChildAfterLogin.fxml",event,Categories.getScene());
            }
        }
        if(event.getSource()==nextButton){
            window("confirm.fxml",event,null);
        }
        if (event.getSource()==update){
            addToOrder();
        }
        if(event.getSource()==c1 ||event.getSource()==c11 ){
            GetColor(event,Colour1);
        }
        if(event.getSource()==c2 || event.getSource()==c22){
            GetColor(event,Colour2);
        }
        if(event.getSource()==c3 || event.getSource()==c33){
            GetColor(event,Colour3);

        }if(event.getSource()==s1 || event.getSource()==s11 ||event.getSource()==s111 || event.getSource()==s1111){
            getSize(event,Size1);
        }if(event.getSource()==s2 || event.getSource()==s22 || event.getSource()==s222 || event.getSource()==s2222){
            getSize(event,Size2);
        }if(event.getSource()==s3 || event.getSource()==s33|| event.getSource()==s333|| event.getSource()==s3333){
            getSize(event,Size3);
        }

    }

    /*@param productNumber,LblPrice,lblColor,lblName,prodCode,lblsize
    * This is a simple method which fills all lables in Woman category by products from database
    *
    * */
    public void LabelsWCat(String no, Label lblPrice, Label lblColor, Label lblName, TextField code, Label lblSize) {
        String sql = "Select prodNumber,price,prodName from products where prodNumber=?";
        try {
            prep = con.prepareStatement(sql);
            prep.setString(1, no);
            param = prep.getParameterMetaData();
            resultSet = prep.executeQuery();
            String price = null;
            String prodNumber = null;
            String prodName = null;
            while (resultSet.next()) {
                prodNumber = resultSet.getString(1);
                price = resultSet.getString(2);
                prodName = resultSet.getString(3);
                System.out.println(prodNumber + " " + price + " " + prodName);
            }
            lblPrice.setText(price + "zł");
            lblPrice.setTextFill(Color.BLACK);
            lblSize.setText("S,M,L,XL");
            lblSize.setTextFill(Color.BLACK);
            lblColor.setText("Black,White");
            lblColor.setTextFill(Color.BLACK);
            lblName.setText(prodName);
            lblName.setTextFill(Color.BLACK);
            code.setText("product code: " + prodNumber);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**@param event , Scene scene =null, String name
     * This is a simple method which opens a window when is called. In parameters takes for few
     *              components a scene, and from everyone name of a window with fxml.
     *
     * */
    public void window(String name, ActionEvent event, Scene scene) throws IOException {
        Stage stage = null;
        if (event.getSource() == WomanCat || event.getSource()==ManCat || event.getSource()==ChildCat) {
            stage = (Stage) scene.getWindow();
        } else {
            node = (Node) event.getSource();
            stage = (Stage) node.getScene().getWindow();
        }
        stage.close();
        scene = new Scene(FXMLLoader.load(getClass().getResource(name)));
        stage.setScene(scene);
        stage.show();

    }
/**@param event
 * This is a simple method used while signining in to an application
 * */
    public void loginButton(ActionEvent event) {
        String email = lblUserName.getText();
        String password = lblPassword.getText();
        String sql = "Select * from users where email = ? and password = ?";

        try {
            prep = con.prepareStatement(sql);
            prep.setString(1, email);
            prep.setString(2, password);
            resultSet = prep.executeQuery();
            if (!resultSet.next()) {
                lblIncorrect.setTextFill(Color.RED);

                lblIncorrect.setText("Incorrect password or email");
            } else {
                System.out.println("correct");
                setUserIsLogged(email);
                System.out.println(lblIncorrect);
                window("MainPageAfterLogIn.fxml", event, null);//Page after signing in
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    /*This is a simple method called while sining up to an application
    *
    * */


    static int idc=0;
    public void signUp() {
        String email = txtNewUser.getText();
        String password = txtNewPass.getText();
        String password2 = txtNewPass2.getText();
        if (!password.equals(password2)) {
            lblError.setTextFill(Color.RED);
            lblError.setText("Passwords are not the same");
        } else {
            String sql = "Insert into users(firstname,surname,email,phoneNumber,address,password) values(null,null,?,null,null,?)";
            try {
                prep = con.prepareStatement(sql);
                prep.setString(1, email);
                prep.setString(2, password);
                prep.executeUpdate();
                System.out.println("correct");
                lblError.setTextFill(Color.GREEN);
                lblError.setText("Check your email for more details");
                String sqlg = "select id from users where email =?";

                prep = con.prepareStatement(sqlg);
                prep.setString(1,email);
                resultSet=prep.executeQuery();
                while(resultSet.next()){
                         idc=resultSet.getInt(1);
                }
                String sql1 = "insert into clients (id) values(?)";
                prep=con.prepareStatement(sql1);
                prep.setInt(1,idc);
                prep.executeUpdate();
                System.out.println(idc);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
/**THis is a simple method used to check if a user is sign in if yes the products he chose are added
 * to productlist from order but not to order yet
 *
 * */
    public void add(ActionEvent event, Scene scene, String prodNumber) throws IOException {
        System.out.println(getUserIsLogged());
        if(getUserIsLogged()==null) {
          window("LoginFirst.fxml", event, scene);
        }else {
            String sql = "Insert into prodlist(prodNumber) values(?)";
            System.out.println(prodNumber);
            try {
                prep = con.prepareStatement(sql);
                prep.setString(1, prodNumber);
                prep.executeUpdate();
                System.out.println("updated prodlist ");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    String payment ="";
    Double money=0.0;
    int first=0;
    int second=0;
    String tab[]= new String[2];
    String tab1[]= new String[2];
    String tab2[]=new String[2];

/*This method
* adds data to components in Order window and also to orrder in database
**/
    public void addToOrder() {
        if (Controller.Box1Distable) {
            sqlOrder(getProdNumber1());
            payment= sqlOrderDetails(getProdNumber1());
            if(payment!=null)
                tab=payment.split(",");

        }
        if (Controller.Box2Distable) {
            sqlOrder(getProdNumber2());
            sqlOrderDetails(getProdNumber2());
            payment=sqlOrderDetails(getProdNumber1());
            if(payment!=null)
                tab1=payment.split(",");
        }
        if (Controller.Box3Distable) {
            sqlOrder(getProdNumber3());
            sqlOrderDetails(getProdNumber3());
            payment=sqlOrderDetails(getProdNumber1());
            if(payment!=null)
                tab2=payment.split(",");
        }
        for(int i =0;i<2; i++){
            if(tab[i]==null)    {
                tab[i]="0";   }
            if(tab1[i]==null) {
                tab1[i]="0";    }
            else if(tab2[i]==null)
                tab2[i]="0";

        }
           first= Integer.parseInt(tab1[0])+Integer.parseInt(tab2[0])+ Integer.parseInt(tab[0]);
           second=Integer.parseInt(tab1[1])+Integer.parseInt(tab2[1])+ Integer.parseInt(tab[1]);

          System.out.println(first+","+second);
        toPay.setText("");
        toPay.setText(first+","+second+" zł");

        String sqlg = "select id from users where email =?";
        try {
          prep = con.prepareStatement(sqlg);
           prep.setString(1, getUserIsLogged());
           resultSet = prep.executeQuery();
            while (resultSet.next()) {
             idc = resultSet.getInt(1);
              }
         }catch (Exception e){
            e.printStackTrace();
         }
        String sqlPrice = "Update orders set price= ? where idClient=?";
        try {
            prep=con.prepareStatement(sqlPrice);
            prep.setString(1,first+","+second);
            prep.setInt(2,idc);
            prep.executeUpdate();
            System.out.println("added price to order for client: "+idc);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        

    }
    static String prodName;
    static String price;

/**This method is used in addToOrder method as sql inejction depending on which addBox
 * is disabled after pressing it
 */

    public String sqlOrderDetails(String prod){
        String sql = "Select prodName, price from products where prodNumber=?";
        try {
            prep = con.prepareStatement(sql);
            prep.setString(1, prod);
            resultSet=prep.executeQuery();
            while(resultSet.next()){
                prodName=resultSet.getString(1);
                price=resultSet.getString(2);
            }
                if (lblorder1.getText().equals("")) {
                    lblorder1.setTextFill(Color.BLACK);
                    lblorder1.setText(prodName);
                    Colour1.setVisible(true);
                    Size1.setVisible(true);
                }
                else if (lblorder2.getText().equals("")) {
                    lblorder2.setTextFill(Color.BLACK);
                    lblorder2.setText(prodName);
                    Colour2.setVisible(true);
                    Size2.setVisible(true);
                } else if(lblorder3.getText().equals(" ")){
                    lblorder3.setTextFill(Color.BLACK);
                    lblorder3.setText(prodName);
                    Colour3.setVisible(true);
                    Size3.setVisible(true);
                }
            return price;

        }catch (Exception e){
            e.printStackTrace();
        }
    return "";
    }
/*This is a method called for updaating order table in databse
*
* */
    static int count ;
    static int id;
    static Date date;
    public void sqlOrder(String prod) {

        try {
            String sql1 = "Select Max(orderNumber) from orders";
            prep = con.prepareStatement(sql1);
            resultSet = prep.executeQuery();
            while (resultSet.next()) {
               Controller.count = resultSet.getInt(1);
            }


            String sql2 = "Select curdate()";
            prep = con.prepareStatement(sql2);
            resultSet = prep.executeQuery();

            while (resultSet.next()) {
                Controller.date = resultSet.getDate(1);
            }



            String sql3 = "Select clients.id from clients inner join users on users.id=clients.id where users.email=?";
            prep = con.prepareStatement(sql3);
            prep.setString(1,getUserIsLogged());
            resultSet= prep.executeQuery();
            while(resultSet.next()){
                Controller.id =resultSet.getInt(1);
            }

            Controller.count++;
            System.out.println(Controller.count);
            String sql4 = "Insert into orders(orderNumber,orderDate,idClient,state)values(?,?,?,?)";
            prep = con.prepareStatement(sql4);
            prep.setInt(1, Controller.count);
            prep.setDate(2, Controller.date);
            prep.setInt(3, Controller.id);
            prep.setString(4, "Złożone");
            prep.executeUpdate();

            String sql5 = "Update prodlist set orderNumber =? where prodNumber = ? and orderNumber=null";
            prep = con.prepareStatement(sql5);
            prep.setString(1,String.valueOf(count));
            prep.setString(2, prod);
            prep.executeUpdate();

        }catch (Exception e) {
            e.printStackTrace();
        }

    }
/*THis method is used to sed colors on lables in Order window depending what user will choose
* */
    public void GetColor(ActionEvent event,MenuButton color) throws IOException {
        System.out.println(event);
        Label label = new Label();
            color.setText("");
            label.setText(((MenuItem) event.getSource()).getText());
            color.setGraphic(label);

    }
    /*THis method is used to sed size on lables in Order window depending what user will choose
     * */
    public void getSize(ActionEvent event,MenuButton size){
        System.out.println(event);
        Label label = new Label();
            size.setText("");
            label.setText(((MenuItem) event.getSource()).getText());
            size.setGraphic(label);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    }
}

