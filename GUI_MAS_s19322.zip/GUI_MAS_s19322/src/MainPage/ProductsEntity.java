package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "products", schema = "masdb", catalog = "")
public class ProductsEntity {
    private int prodNumber;
    private String price;
    private String color;
    private String prodName;
    private Integer idCategory;

    @Id
    @Column(name = "prodNumber", nullable = false)
    public int getProdNumber() {
        return prodNumber;
    }

    public void setProdNumber(int prodNumber) {
        this.prodNumber = prodNumber;
    }

    @Basic
    @Column(name = "price", nullable = true, length = -1)
    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Basic
    @Column(name = "color", nullable = true, length = -1)
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Basic
    @Column(name = "prodName", nullable = true, length = -1)
    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    @Basic
    @Column(name = "idCategory", nullable = true)
    public Integer getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(Integer idCategory) {
        this.idCategory = idCategory;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductsEntity that = (ProductsEntity) o;
        return prodNumber == that.prodNumber &&
                Objects.equals(price, that.price) &&
                Objects.equals(color, that.color) &&
                Objects.equals(prodName, that.prodName) &&
                Objects.equals(idCategory, that.idCategory);
    }

    @Override
    public int hashCode() {
        return Objects.hash(prodNumber, price, color, prodName, idCategory);
    }
}
