package MainPage;

public class ShopWearIt {

    public static void main(String[] args) throws Exception {
        DBConnection con = new DBConnection();
        System.out.println(con.conDB());
    }
}