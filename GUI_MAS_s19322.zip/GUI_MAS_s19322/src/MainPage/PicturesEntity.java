package MainPage;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Objects;

@Entity
@Table(name = "pictures", schema = "masdb", catalog = "")
public class PicturesEntity {
    private int imageId;
    private Integer prodNumber;
    private byte[] image;

    @Id
    @Column(name = "imageId", nullable = false)
    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    @Basic
    @Column(name = "prodNumber", nullable = true)
    public Integer getProdNumber() {
        return prodNumber;
    }

    public void setProdNumber(Integer prodNumber) {
        this.prodNumber = prodNumber;
    }

    @Basic
    @Column(name = "image", nullable = true)
    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PicturesEntity that = (PicturesEntity) o;
        return imageId == that.imageId &&
                Objects.equals(prodNumber, that.prodNumber) &&
                Arrays.equals(image, that.image);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(imageId, prodNumber);
        result = 31 * result + Arrays.hashCode(image);
        return result;
    }
}
