package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "black", schema = "masdb", catalog = "")
public class BlackEntity {
    private int idColor;
    private Integer prodNumber;
    private Integer amount;

    @Id
    @Column(name = "idColor", nullable = false)
    public int getIdColor() {
        return idColor;
    }

    public void setIdColor(int idColor) {
        this.idColor = idColor;
    }

    @Basic
    @Column(name = "prodNumber", nullable = true)
    public Integer getProdNumber() {
        return prodNumber;
    }

    public void setProdNumber(Integer prodNumber) {
        this.prodNumber = prodNumber;
    }

    @Basic
    @Column(name = "amount", nullable = true)
    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BlackEntity that = (BlackEntity) o;
        return idColor == that.idColor &&
                Objects.equals(prodNumber, that.prodNumber) &&
                Objects.equals(amount, that.amount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idColor, prodNumber, amount);
    }
}
