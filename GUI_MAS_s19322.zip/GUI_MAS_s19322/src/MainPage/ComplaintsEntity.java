package MainPage;

import javax.persistence.*;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "complaints", schema = "masdb", catalog = "")
public class ComplaintsEntity {
    private int id;
    private String orderNumber;
    private Integer idWorker;
    private Date subDate;
    private Date endDate;
    private String msg;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "orderNumber", nullable = false, length = -1)
    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    @Basic
    @Column(name = "idWorker", nullable = true)
    public Integer getIdWorker() {
        return idWorker;
    }

    public void setIdWorker(Integer idWorker) {
        this.idWorker = idWorker;
    }

    @Basic
    @Column(name = "subDate", nullable = true)
    public Date getSubDate() {
        return subDate;
    }

    public void setSubDate(Date subDate) {
        this.subDate = subDate;
    }

    @Basic
    @Column(name = "endDate", nullable = true)
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @Basic
    @Column(name = "msg", nullable = true, length = -1)
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ComplaintsEntity that = (ComplaintsEntity) o;
        return id == that.id &&
                Objects.equals(orderNumber, that.orderNumber) &&
                Objects.equals(idWorker, that.idWorker) &&
                Objects.equals(subDate, that.subDate) &&
                Objects.equals(endDate, that.endDate) &&
                Objects.equals(msg, that.msg);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, orderNumber, idWorker, subDate, endDate, msg);
    }
}
