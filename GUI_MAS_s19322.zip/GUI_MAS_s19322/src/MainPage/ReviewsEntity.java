package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "reviews", schema = "masdb", catalog = "")
public class ReviewsEntity {
    private int id;
    private Integer clientId;
    private Integer starsNumber;
    private String review;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "clientId", nullable = true)
    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    @Basic
    @Column(name = "starsNumber", nullable = true)
    public Integer getStarsNumber() {
        return starsNumber;
    }

    public void setStarsNumber(Integer starsNumber) {
        this.starsNumber = starsNumber;
    }

    @Basic
    @Column(name = "review", nullable = true, length = -1)
    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReviewsEntity that = (ReviewsEntity) o;
        return id == that.id &&
                Objects.equals(clientId, that.clientId) &&
                Objects.equals(starsNumber, that.starsNumber) &&
                Objects.equals(review, that.review);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, clientId, starsNumber, review);
    }
}
