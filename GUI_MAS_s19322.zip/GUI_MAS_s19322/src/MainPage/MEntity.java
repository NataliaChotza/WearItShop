package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "m", schema = "masdb")//, catalog = "")
public class MEntity {
    private int idM;
    private Integer prodNumber;
    private Integer ammount;

    @Id
    @Column(name = "idM", nullable = false)
    public int getIdM() {
        return idM;
    }

    public void setIdM(int idM) {
        this.idM = idM;
    }

    @Basic
    @Column(name = "prodNumber", nullable = true)
    public Integer getProdNumber() {
        return prodNumber;
    }

    public void setProdNumber(Integer prodNumber) {
        this.prodNumber = prodNumber;
    }

    @Basic
    @Column(name = "ammount", nullable = true)
    public Integer getAmmount() {
        return ammount;
    }

    public void setAmmount(Integer ammount) {
        this.ammount = ammount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MEntity mEntity = (MEntity) o;
        return idM == mEntity.idM &&
                Objects.equals(prodNumber, mEntity.prodNumber) &&
                Objects.equals(ammount, mEntity.ammount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idM, prodNumber, ammount);
    }
}
