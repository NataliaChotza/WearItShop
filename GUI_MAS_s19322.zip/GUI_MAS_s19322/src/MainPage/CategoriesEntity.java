package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "categories", schema = "masdb", catalog = "")
public class CategoriesEntity {
    private int idCategory;
    private String catName;

    @Id
    @Column(name = "idCategory", nullable = false)
    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    @Basic
    @Column(name = "catName", nullable = true, length = -1)
    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoriesEntity that = (CategoriesEntity) o;
        return idCategory == that.idCategory &&
                Objects.equals(catName, that.catName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCategory, catName);
    }
}
