package MainPage;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "s", schema = "masdb", catalog = "")
public class SEntity {
    private int idS;
    private Integer prodNumber;
    private Integer ammount;

    @Id
    @Column(name = "idS", nullable = false)
    public int getIdS() {
        return idS;
    }

    public void setIdS(int idS) {
        this.idS = idS;
    }

    @Basic
    @Column(name = "prodNumber", nullable = true)
    public Integer getProdNumber() {
        return prodNumber;
    }

    public void setProdNumber(Integer prodNumber) {
        this.prodNumber = prodNumber;
    }

    @Basic
    @Column(name = "ammount", nullable = true)
    public Integer getAmmount() {
        return ammount;
    }

    public void setAmmount(Integer ammount) {
        this.ammount = ammount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SEntity sEntity = (SEntity) o;
        return idS == sEntity.idS &&
                Objects.equals(prodNumber, sEntity.prodNumber) &&
                Objects.equals(ammount, sEntity.ammount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idS, prodNumber, ammount);
    }
}
